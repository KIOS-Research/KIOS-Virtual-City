The program will run all INP files in the Nets sub-directory.
A report, binary output files and a .dif file will be created for each INP file.
The report is the min(�log10(abs(X1-X2))) where X1 and X2 are the results arrays obtains from the two binary files.

Files needed in the code directory:
epanet2d.exe is the official EPANET standalone version.
epanet2.exe is the current development version (the one being tested).

How to use: run the program and click the RUN button.

By Elad Salomons
email: selad@optiwater.com